from setuptools import setup

setup(name='aina_visualiser',
      version='0.1',
      description='Data Visualization',
      packages=['aina_visualiser'],
      zip_safe=False)
